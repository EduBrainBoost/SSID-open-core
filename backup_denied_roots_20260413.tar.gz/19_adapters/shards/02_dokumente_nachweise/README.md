# 19_adapters/02_dokumente_nachweise

Capability definition for deterministic shard contract baseline.
