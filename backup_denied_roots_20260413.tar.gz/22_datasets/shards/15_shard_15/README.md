# 22_datasets/15_shard_15

Capability definition for deterministic shard contract baseline.
