# 04_deployment/08_shard_08

Capability definition for deterministic shard contract baseline.
