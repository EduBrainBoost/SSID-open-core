"""EMS API schemas."""
