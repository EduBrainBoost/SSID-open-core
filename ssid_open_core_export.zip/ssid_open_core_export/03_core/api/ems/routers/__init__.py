"""EMS API routers."""
