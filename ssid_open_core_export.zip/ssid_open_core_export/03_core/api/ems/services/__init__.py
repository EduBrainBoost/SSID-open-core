"""EMS service layer."""
