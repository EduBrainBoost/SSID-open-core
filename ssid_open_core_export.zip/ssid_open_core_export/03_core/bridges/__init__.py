"""Core bridge modules."""
